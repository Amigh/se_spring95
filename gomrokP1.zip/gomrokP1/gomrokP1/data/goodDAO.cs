﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace gomrokP1.data
{
    class goodDAO:baseDB
    {

        static goodDAO gd = null;
        public static goodDAO getInstance()
        {
            if(gd == null)
                gd = new goodDAO();
            return gd;
        }

        public Good findGoodById(int id)
        {
            string query = "SELECT * FROM [good] WHERE id=@id";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@id", id));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            DataRow row = ds.Tables[0].Rows[0];
            int db_id = Convert.ToInt32(row.ItemArray.GetValue(0));
            string db_name = row.ItemArray.GetValue(1).ToString();
            return new Good(db_name, db_id);
        }

        public Good findGoodByName(String name)
        {
            string query = "SELECT * FROM [good] WHERE name=@name";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@name", name));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            DataRow row = ds.Tables[0].Rows[0];
            int db_id = Convert.ToInt32(row.ItemArray.GetValue(0));
            string db_name = row.ItemArray.GetValue(1).ToString();
            return new Good(db_name,db_id);
        }

        public void insert(Good g)
        {
            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [good] (name) VALUES (@name) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@name", g.getName()));
            Insert(query, qparams);
        }


    }
}
