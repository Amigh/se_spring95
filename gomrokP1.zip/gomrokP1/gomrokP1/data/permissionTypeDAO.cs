﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using gomrokP1.logic;
using System.Data.SqlClient;
using System.Data;

namespace gomrokP1.data
{
    class permissionTypeDAO : baseDB
    {
        static permissionTypeDAO ptd = null;
        static public permissionTypeDAO getInstance()
        {
            if (ptd == null)
                ptd = new permissionTypeDAO();
            return ptd;
        }

        public PermissionType findById(int id){
            string query = "SELECT * FROM [permissionType] where id=@id";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@id", id));
            DataSet ds = getDataSet(query,qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            return new PermissionType((int)ds.Tables[0].Rows[0].ItemArray.GetValue(0), (string)ds.Tables[0].Rows[0].ItemArray.GetValue(1));
        }

        public int getLastId()
        {
            string query = "SELECT max(id) FROM [permissionType] as lastId";
            DataSet ds = getDataSet(query, null);
            if (ds.Tables[0].Rows.Count == 0)
                return 1;
            return Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray.GetValue(0));
        }


        public int insertPermissionType(PermissionType pt)
        {
            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [permissionType] (description) VALUES (@description) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@description", pt.description));
            Insert(query, qparams);
            return getLastId();
        }




    }
}
