﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using gomrokP1.logic;
using System.Data.SqlClient;
using System.Data;

namespace gomrokP1.data
{
    class permissionRoleDAO:baseDB
    {
        static permissionRoleDAO ptd = null;
        static public permissionRoleDAO getInstance()
        {
            if (ptd == null)
                ptd = new permissionRoleDAO();
            return ptd;
        }

        public bool hasPermissionRole(string role,int permissionTypeId){
            string query = "SELECT * FROM [permissionRole] where permissionType=@permissionType and role=@role";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@permissionType", permissionTypeId));
            qparams.Add(new SqlParameter("@role", role));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return false;
            else 
                return true;      
        }

        public void insertPermissionRole(PermissionRole pt)
        {
            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [permissionRole] (permissionType,role) VALUES (@permissionType,@role) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@permissionType", pt.permissionTypeId));
            qparams.Add(new SqlParameter("@role", pt.role));
            Insert(query, qparams);
        }
    }
}

