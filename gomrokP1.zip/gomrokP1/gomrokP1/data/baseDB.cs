﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace gomrokP1
{
    class baseDB
    {

     

        public void Insert(string query, List<SqlParameter> qparams)
        {
            string conStr = @" Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Ali\Desktop\gomrokP1\gomrokP1\Database.mdf; Integrated Security = True; Connect Timeout = 15; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False;";

            using (SqlConnection connection = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand(query);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connection;
                if (qparams != null)
                    foreach (SqlParameter p in qparams)
                        cmd.Parameters.Add(p);
                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }


        public DataSet getDataSet(string query, List<SqlParameter> qparams)
        {
            string conStr = @" Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Ali\Desktop\gomrokP1\gomrokP1\Database.mdf; Integrated Security = True; Connect Timeout = 15; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False;";
            SqlConnection conn = new SqlConnection(conStr);
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            if (qparams != null)
                foreach (SqlParameter p in qparams)
                    da.SelectCommand.Parameters.Add(p);
            DataSet data_set = new DataSet();
            da.Fill(data_set);
            conn.Close();
            return data_set;
        }


        //public void Select(string query, List<SqlParameter> qparams)
        //{

        //    string conStr = @" Data Source = HOME\SQLEXPRESS; Initial Catalog = database; Integrated Security = True; Connect Timeout = 15; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False;";


        //    using (SqlConnection connection = new SqlConnection(conStr))
        //    {
        //        SqlCommand cmd = new SqlCommand(query);
        //        cmd.CommandType = CommandType.Text;
        //        cmd.Connection = connection;
        //        if (qparams != null)
        //            foreach (SqlParameter p in qparams)
        //                cmd.Parameters.Add(p);
        //        connection.Open();
        //        cmd.ExecuteNonQuery();
        //    }
        //}

    }
}
