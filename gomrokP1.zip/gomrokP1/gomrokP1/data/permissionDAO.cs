﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using gomrokP1.logic;

namespace gomrokP1.data
{
    class permissionDAO : baseDB
    {
        static permissionDAO pd = null;
        static public permissionDAO getInstance()
        {
            if (pd == null)
                pd = new permissionDAO();
            return pd;
        }

        public int getLastId()
        {
            string query = "SELECT max(id) FROM [permission] as lastId";
            DataSet ds = getDataSet(query, null);
            if (ds.Tables[0].Rows.Count == 0)
                return 10000000;
            return Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray.GetValue(0));
        }

        public Permission findPermissionById(int id){
            int goodId,permissionTypeId;
            Good good;
            string busManSSN,compony,transportType,empUserName,srcCountry;
            int? quantity, minFee, maxFee;
            DateTime? expDate; 
            string query = "SELECT * FROM [permission] WHERE id=@id";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@id", id));
            System.Data.DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            System.Data.DataRow row = ds.Tables[0].Rows[0];
            goodId = Convert.ToInt32(row.ItemArray.GetValue(1));
            good = goodDAO.getInstance().findGoodById(goodId);
            busManSSN = row.ItemArray.GetValue(2).ToString();
            permissionTypeId = Convert.ToInt32(row.ItemArray.GetValue(11));
            if (row.ItemArray.GetValue(3) == DBNull.Value)
                quantity = null;
            else
                quantity = Convert.ToInt32(row.ItemArray.GetValue(3));
            if (row.ItemArray.GetValue(4) == DBNull.Value)
                expDate = null;
            else
                expDate = Convert.ToDateTime(row.ItemArray.GetValue(4));
            if (row.ItemArray.GetValue(5) == DBNull.Value)
                compony = null;
            else
                compony = row.ItemArray.GetValue(5).ToString();
            if (row.ItemArray.GetValue(6) == DBNull.Value)
                transportType = null;
            else
                transportType = row.ItemArray.GetValue(6).ToString();
            if (row.ItemArray.GetValue(7) == DBNull.Value)
                minFee = null;
            else
                minFee = Convert.ToInt32(row.ItemArray.GetValue(7));
            if (row.ItemArray.GetValue(8) == DBNull.Value)
                maxFee = null;
            else
                maxFee = Convert.ToInt32(row.ItemArray.GetValue(8));
            empUserName = row.ItemArray.GetValue(9).ToString();
            if (row.ItemArray.GetValue(10) == DBNull.Value)
                srcCountry = null;
            else
                srcCountry = row.ItemArray.GetValue(10).ToString();
            return new Permission(permissionTypeId, good, busManSSN, quantity, expDate, compony, transportType, minFee, maxFee, empUserName, srcCountry);
        }

        public string insertPermission(Permission p)
        {
            Good good = goodDAO.getInstance().findGoodByName(p.getGood().getName());
            if (good == null)
            {
                goodDAO.getInstance().insert(p.getGood());
                good = goodDAO.getInstance().findGoodByName(p.getGood().getName());

            }
            if (busmanDAO.getInstance().findBusinessManBySSN(p.getBusManSSN()) == null)
                busmanDAO.getInstance().insert(new businessMan("","",p.getBusManSSN()));
            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [permission] (good_id,bus_man_ssn,quantity,expire_date,compony,transport_type,fee_min,fee_max,emp_username,source_country,permission_type_id) VALUES (@good_id,@bus_man_ssn,@quantity,@expire_date,@compony,@transport_type,@fee_min,@fee_max,@emp_username,@source_country,@permission_type_id) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@good_id", good.getId()));
            qparams.Add(new SqlParameter("@bus_man_ssn", p.getBusManSSN()));
            qparams.Add(new SqlParameter("@quantity", (object)p.getQuantity() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@expire_date", (object)p.getExpDate() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@compony", (object)p.getCompony() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@transport_type", (object)p.getTransportType() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@fee_min", (object)p.getMinFee() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@fee_max", (object)p.getMaxFee() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@emp_username", (object)p.getEmpUserName() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@source_country", (object)p.getSrcCountry() ?? DBNull.Value));
            qparams.Add(new SqlParameter("@permission_type_id", p.getPermissionTypeId()));
            Insert(query, qparams);
            return Convert.ToString(getLastId());
        }

        public void updatePermission(int id,int newQuantity)
        {
            string query;
            List<SqlParameter> qparams;
            query = "update [permission] SET quantity=@quantity WHERE id=@id";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@id", id));
            qparams.Add(new SqlParameter("@quantity", newQuantity));
            Insert(query, qparams);
        }
    }
}
