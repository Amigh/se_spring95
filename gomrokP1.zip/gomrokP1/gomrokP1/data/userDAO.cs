﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace gomrokP1
{
    class userDAO : baseDB
    {
        static userDAO udo = null;

      
        public static userDAO getInstance()
        {
            if (udo == null)
            {
                udo = new userDAO();
            }
            return udo;
        }


        public void insertUser(Employee e)
        {
            
            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [user] (username,password,role) VALUES (@user,@password,@role) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@user", e.getUsername()));
            qparams.Add(new SqlParameter("@password",e.getPassword() ));
            qparams.Add(new SqlParameter("@role", e.getRole()));
            Insert(query, qparams);
        }

        public Employee authenthicate(string username, string password)
        {
            string query = "SELECT * FROM [user] WHERE username=@username and password=@password";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@username", username));
            qparams.Add(new SqlParameter("@password", password));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            DataRow row = ds.Tables[0].Rows[0];

            string db_username = row.ItemArray.GetValue(0).ToString();
            string db_password = row.ItemArray.GetValue(1).ToString();
            string db_role = row.ItemArray.GetValue(2).ToString();
            return new Employee(db_username,db_password,db_role);

        }

       
    }
}
