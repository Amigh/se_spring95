﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using gomrokP1.data;
using gomrokP1.logic;
namespace gomrokP1
{
    class ezharDAO : baseDB
    {
        static ezharDAO edao = null;

        public static ezharDAO getInstance()
        {
            if (edao == null)
            {
                edao = new ezharDAO();
            }
            return edao;
        }

        public void insertEzhar(Ezhar e,String username)
        {

            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [ezharname] (bus_man_ssn,emp_username,submit_date,total_val,source_country,transport_type) VALUES (@bus_man_ssn,@emp_username,@submit_date,@total_val,@source_country,@transport_type) ";
            qparams = new List<SqlParameter>();
            int ezharId = findIdEzhar(e, username);
            if (busmanDAO.getInstance().findBusinessManBySSN(e.getBusinessMan().ssn) == null)
                busmanDAO.getInstance().insert(e.getBusinessMan());
            else
                busmanDAO.getInstance().updateBusManInfo(e.getBusinessMan().ssn,e.getBusinessMan().fname,e.getBusinessMan().lname);
            if (ezharId == -1)
            {
                qparams.Add(new SqlParameter("@bus_man_ssn", e.getBusinessMan().ssn));
                qparams.Add(new SqlParameter("@emp_username", username));
                qparams.Add(new SqlParameter("@submit_date", e.getDate()));
                qparams.Add(new SqlParameter("@total_val", e.getTotalVal()));
                qparams.Add(new SqlParameter("@source_country", e.getSourceCountry()));
                qparams.Add(new SqlParameter("@transport_type", e.getTransportType()));
                Insert(query, qparams);
                ezharId = getLastId();
            }
            goodDAO gd = goodDAO.getInstance();
            descriptionDAO dd = descriptionDAO.getInstance();


            foreach (GoodItem gi in e.getGoods())
            {
                Good good = gd.findGoodByName(gi.getGood().getName());

                if (good == null)
                {
                    gd.insert(gi.getGood());
                    good = gd.findGoodByName(gi.getGood().getName());

                }
                Description desc = gi.getDescription();
                if (dd.findDescriptionByValues(desc.fee, desc.weight, good.getId(), desc.company) == null)
                {
                    dd.insert(desc, good.getId());
                }
                desc = dd.findDescriptionByValues(desc.fee, desc.weight, good.getId(), desc.company);
                ezharnameGoodDAO egd = ezharnameGoodDAO.getInstance();

                if (egd.hasEzharGood(desc.id, ezharId) == false)
                    egd.insert(desc.id, ezharId, gi.getQuntity());
                else
                {
                    //update ezhar_goods
                }

            }

        }

        public int getLastId()
        {
            string query = "SELECT max(id) FROM [ezharname] as lastId";
            DataSet ds = getDataSet(query, null);
            if (ds.Tables[0].Rows.Count == 0)
                return 1;
            return Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray.GetValue(0));
        }

        public int findIdEzhar(Ezhar e,string username)
        {
            string query = "SELECT * FROM [ezharname] WHERE bus_man_ssn=@bus_man_ssn and emp_username=@emp_username and total_val=@total_val and source_country=@source_country and transport_type = @transport_type ";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@bus_man_ssn", e.getBusinessMan().ssn));
            qparams.Add(new SqlParameter("@emp_username", username));
            //qparams.Add(new SqlParameter("@submit_date", e.getDate()));
            qparams.Add(new SqlParameter("@total_val", e.getTotalVal()));
            qparams.Add(new SqlParameter("@source_country", e.getSourceCountry()));
            qparams.Add(new SqlParameter("@transport_type", e.getTransportType()));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return -1;
            DataRow row = ds.Tables[0].Rows[0];
            int db_id = Convert.ToInt32(row.ItemArray.GetValue(0));
            return db_id;
        }

    }
}
