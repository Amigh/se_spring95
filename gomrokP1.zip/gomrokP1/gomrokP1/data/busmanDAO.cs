﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using gomrokP1.logic;

namespace gomrokP1.data
{
    class busmanDAO:baseDB
    {
        static busmanDAO bd = null;
        static public busmanDAO getInstance()
        {
            if(bd == null)
                bd = new busmanDAO();
            return bd;
        }

        public businessMan findBusinessManBySSN(String ssn)
        {
            string query = "SELECT * FROM [bus_man] WHERE ssn=@ssn";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@ssn", ssn));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            DataRow row = ds.Tables[0].Rows[0];
            
            string db_fname = row.ItemArray.GetValue(0).ToString();
            string db_lname = row.ItemArray.GetValue(1).ToString();
            string db_ssn = row.ItemArray.GetValue(2).ToString();
            return new businessMan(db_fname, db_lname,ssn);
        }



        public void updateBusManInfo(string ssn, string name,string family)
        {
            string query;
            List<SqlParameter> qparams;
            query = "update [bus_man] SET firstName=@firstName,lastName=@lastName WHERE ssn=@ssn";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@firstName", name));
            qparams.Add(new SqlParameter("@lastName", family));
            qparams.Add(new SqlParameter("@ssn", ssn));
            Insert(query, qparams);
        }

        public void insert(businessMan b)
        {

            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [bus_man] (firstName,lastName,ssn) VALUES (@fname,@lname,@ssn) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@fname", b.fname));
            qparams.Add(new SqlParameter("@lname", b.lname));
            qparams.Add(new SqlParameter("@ssn", b.ssn));
            Insert(query, qparams);
        }
    }
}
