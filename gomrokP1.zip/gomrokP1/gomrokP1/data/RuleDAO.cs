﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using gomrokP1.logic;
using gomrokP1;
using System.Data.SqlClient;
namespace gomrokP1.data
{
    class RuleDAO :baseDB
    {
        static RuleDAO rd = null;
        static public RuleDAO getInstance()
        {
            if (rd == null)
                rd = new RuleDAO();
            return rd;
        }

        public void insertRule(MyRule rule)
        {
            Good good = goodDAO.getInstance().findGoodByName(rule.getGood().getName());
            if (good == null)
            {
                goodDAO.getInstance().insert(rule.getGood());
                good = goodDAO.getInstance().findGoodByName(rule.getGood().getName());

            }
            string query;
            List<SqlParameter> qparams;
                query = "INSERT INTO [rule] (good_id,min_quantity,max_quantity,min_fee,max_fee,permissionType) VALUES (@good_id,@min_quantity,@max_quantity,@min_fee,@max_fee,@permissionType) ";
                qparams = new List<SqlParameter>();
                qparams.Add(new SqlParameter("@good_id", good.getId()));
                qparams.Add(new SqlParameter("@min_quantity", rule.getMinQuantity()));
                qparams.Add(new SqlParameter("@max_quantity", rule.getMaxQuantity()));
                qparams.Add(new SqlParameter("@min_fee", rule.getMinFee()));
                qparams.Add(new SqlParameter("@max_fee", rule.getMaxFee()));
                qparams.Add(new SqlParameter("@permissionType", rule.getPermit()));
            
                Insert(query, qparams);
            
        }

        public List<MyRule> findRulesByGoodName(string goodName){
            List<MyRule> rules = new List<MyRule>();
            int id;
            int? minQuantity,maxQuantity,minFee,maxFee;
            Good good = goodDAO.getInstance().findGoodByName(goodName);
            if(good == null)
                return rules;
            string query = "SELECT * FROM [rule] WHERE good_id=@good_id";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@good_id",good.getId()));
            System.Data.DataSet ds = getDataSet(query, qparams);
            foreach (System.Data.DataRow row in ds.Tables[0].Rows)
            {
                id = Convert.ToInt32(row.ItemArray.GetValue(0));
                if (row.ItemArray.GetValue(2) == DBNull.Value)
                    minQuantity = null;
                else
                    minQuantity = Convert.ToInt32(row.ItemArray.GetValue(2));
                if (row.ItemArray.GetValue(3) == DBNull.Value)
                    maxQuantity = null;
                else
                    maxQuantity = Convert.ToInt32(row.ItemArray.GetValue(3));
                if (row.ItemArray.GetValue(4) == DBNull.Value)
                    minFee = null;
                else
                    minFee = Convert.ToInt32(row.ItemArray.GetValue(4));
                if (row.ItemArray.GetValue(5) == DBNull.Value)
                    maxFee = null;
                else
                    maxFee = Convert.ToInt32(row.ItemArray.GetValue(5));
                int permitId = Convert.ToInt32(row.ItemArray.GetValue(6));
                rules.Add(new MyRule(id,good,minQuantity,maxQuantity,minFee,maxFee,permitId));
            }
            return rules;
        }
    }
}
