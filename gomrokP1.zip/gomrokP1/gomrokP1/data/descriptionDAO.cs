﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using gomrokP1.logic;

namespace gomrokP1.data
{
    class descriptionDAO:baseDB
    {
        static descriptionDAO dd = null;
        public static descriptionDAO getInstance()
        {
            if (dd == null)
                dd = new descriptionDAO();
            return dd;
        }
        public Description findDescriptionByValues(int fee,int weight,int goodId,string company)
        {
            string query = "SELECT * FROM [description] WHERE fee=@fee and weight=@weight and goodId=@goodId and company=@company";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@fee",fee ));
            qparams.Add(new SqlParameter("@weight",weight ));
            qparams.Add(new SqlParameter("@goodId",goodId ));
            qparams.Add(new SqlParameter("@company", company));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return null;
            DataRow row = ds.Tables[0].Rows[0];
            int db_id = Convert.ToInt32(row.ItemArray.GetValue(0));
            int db_fee = Convert.ToInt32(row.ItemArray.GetValue(1));
            int db_weight = Convert.ToInt32(row.ItemArray.GetValue(2));
            string db_company = row.ItemArray.GetValue(3).ToString();
            int db_goodId = Convert.ToInt32(row.ItemArray.GetValue(4));
            return new Description(db_company, db_fee,db_weight,db_id,db_goodId);
        }





        public void insert(Description d,int goodId)
        {

            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [description] (fee,weight,company,goodId) VALUES (@fee,@weight,@company,@goodId) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@fee", d.fee));
            qparams.Add(new SqlParameter("@weight", d.weight));
            qparams.Add(new SqlParameter("@company", d.company));
            qparams.Add(new SqlParameter("@goodId", goodId));
            Insert(query, qparams);
        }

    }
}
