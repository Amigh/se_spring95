﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace gomrokP1.data
{
    class ezharnameGoodDAO:baseDB
    {
        static ezharnameGoodDAO egd = null;
        public static ezharnameGoodDAO getInstance()
        {
            if (egd == null)
                egd = new ezharnameGoodDAO();
            return egd;
        }
        public bool hasEzharGood(int descriptionId,int ezharId)
        {
            string query = "SELECT * FROM [ezhar_goods] WHERE description_id=@descriptionId and ezhar_id=@ezharId";
            List<SqlParameter> qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@descriptionId", descriptionId));
            qparams.Add(new SqlParameter("@ezharId", ezharId));
            DataSet ds = getDataSet(query, qparams);
            if (ds.Tables[0].Rows.Count == 0)
                return false;
            return true;
        }

        public void insert(int descriptionId,int ezharId,double quantity)
        {
            string query;
            List<SqlParameter> qparams;
            query = "INSERT INTO [ezhar_goods] (description_id,ezhar_id,quantity) VALUES (@descriptionId,@ezharId,@quantity) ";
            qparams = new List<SqlParameter>();
            qparams.Add(new SqlParameter("@descriptionId", descriptionId));
            qparams.Add(new SqlParameter("@ezharId", ezharId));
            qparams.Add(new SqlParameter("@quantity", quantity));
            Insert(query, qparams);
        }


    }
}
