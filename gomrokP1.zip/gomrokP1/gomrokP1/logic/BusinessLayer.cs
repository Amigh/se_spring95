﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using gomrokP1.data;
using gomrokP1.logic;

namespace gomrokP1
{
    class BusinessLayer
    {
        Employee currentUser;
        static BusinessLayer instance = null;
        public static BusinessLayer getInstance()
        {
            if (instance == null)
            {
                instance = new BusinessLayer();
                return instance;
            }
            else
                return instance;
        }


        public void addRule(MyRule myRule)
        {
            RuleDAO rd = RuleDAO.getInstance();
            rd.insertRule(myRule);
        }

        public bool doesPermissionTypeExist(int id){
            if (permissionTypeDAO.getInstance().findById(id) == null)
                return false;
            else
                return true;
        }

        public bool isCurrUserAuthorisedForPermission(int permissionTypeId){
            if (permissionRoleDAO.getInstance().hasPermissionRole(this.currentUser.getRole(), permissionTypeId))
                return true;
            else
                return false;
        }

        public void setCurrentUser(Employee currentUser)
        {
            
            this.currentUser = currentUser;
        }
        public bool isCurrentUserAdmin()
        {
            if (this.currentUser != null)
            {
                if(this.currentUser.getRole().Trim().Equals("admin"))
                {
                    return true;
                }

            }
            return false;
        }
        public void logOut()
        {
            this.currentUser = null;
        }
        public void signUp(string username, string password, string role)
        {
            Employee newEmp = new Employee(username, password, role);
            userDAO.getInstance().insertUser(newEmp);            
        }

        public bool login(string username,string password)
        {
            Employee e = userDAO.getInstance().authenthicate(username,password);
            if (e == null)
                return false;
            else {
                this.currentUser = e;
                return true;
            }
      
        }

        public void addEzhar(Ezhar e)
        {

            ezharDAO.getInstance().insertEzhar(e,currentUser.getUsername());
        }

        public string addPermission(Permission permission)
        {
            permission.setEmpUserName(currentUser.getUsername());
            return permissionDAO.getInstance().insertPermission(permission);
        }

        public int addPermissionType(PermissionType pt)
        {
            return permissionTypeDAO.getInstance().insertPermissionType(pt);
        }

        public void addPermissionRole(PermissionRole pr)
        {
            permissionRoleDAO.getInstance().insertPermissionRole(pr);
        }

        public List<Tuple<GoodItem, PermissionType>> getEzharReqPermits(Ezhar ezhar)
        {
            
            List<Tuple<GoodItem,PermissionType>> reqPermits = new List<Tuple<GoodItem,PermissionType>>();
            List<MyRule> rules;
            Boolean match;
            foreach (GoodItem gi in ezhar.getGoods())
            {
                rules = RuleDAO.getInstance().findRulesByGoodName(gi.getGood().getName());
                foreach(MyRule rule in rules){
                    match = true;
                    if(rule.getMinQuantity() !=null && rule.getMinQuantity() > gi.getQuntity())
                        match = false;
                    if (rule.getMaxQuantity() != null && rule.getMaxQuantity() < gi.getQuntity())
                        match = false;
                    if (rule.getMinFee() != null && rule.getMinFee() > gi.getDescription().fee)
                        match = false;
                    if (rule.getMaxFee() != null && rule.getMaxFee() < gi.getDescription().fee)
                        match = false;
                    if (match)
                    {
                        PermissionType permissionType = permissionTypeDAO.getInstance().findById(rule.getPermit());
                        reqPermits.Add(Tuple.Create(gi, permissionType));
                    }
                }
            }
            return reqPermits;
        }


        public Result isEzharPermitsCorrect(Ezhar ezhar)
        {
            Boolean isSuccess = true;
            string message = "";
            int permitId;
            List<string> mismatchParam = new List<string>();
            foreach (GoodItem gi in ezhar.getGoods())
            {

                foreach (KeyValuePair<PermissionType, string> entry in gi.getPermisions())
                {
                    PermissionType pt = entry.Key;
                    string permitIdStr = entry.Value;
                    mismatchParam.Clear();
                    if (permitIdStr == "")
                    {
                        isSuccess = false;
                        message += "مجوز کالای " + gi.getGood().getName() + " را وارد نکردید" + "\n";
                        continue;
                    }
                    permitId = Convert.ToInt32(permitIdStr);
                    Permission permission = permissionDAO.getInstance().findPermissionById(permitId);
                    if (permission == null)
                    {
                        isSuccess = false;
                        message += "مجوز کالای " + gi.getGood().getName() + " پیدا نشد" + "\n";
                        continue;
                    }
                    if (permission.getBusManSSN() != ezhar.getBusinessMan().ssn)
                        mismatchParam.Add("کد ملی تاجر");
                    if(permission.getPermissionTypeId() != pt.id)
                        mismatchParam.Add("نوع مجوز");
                    if (permission.getGood().getName() != gi.getGood().getName())
                        mismatchParam.Add("نام کالا");
                    if (permission.getQuantity() != null && permission.getQuantity() < gi.getQuntity())
                        mismatchParam.Add("تعداد کالا");
                    if (permission.getExpDate() != null && permission.getExpDate() < ezhar.getDate())
                        mismatchParam.Add("تاریخ انقضا");
                    if (permission.getCompony() != null && permission.getCompony() != gi.getDescription().company)
                        mismatchParam.Add("شرکت سازنده");
                    if (permission.getTransportType() != null && permission.getTransportType() != ezhar.getTransportType())
                        mismatchParam.Add("نحوه ورود");
                    if (permission.getMinFee() != null && permission.getMinFee() > gi.getDescription().fee)
                        mismatchParam.Add("حداقل ارزش واحد");
                    if (permission.getMaxFee() != null && permission.getMaxFee() < gi.getDescription().fee)
                        mismatchParam.Add("حداکثر ارزش واحد");
                    if (permission.getSrcCountry() != null && permission.getSrcCountry() != ezhar.getSourceCountry())
                        mismatchParam.Add("کشور مبدا");

                    if (mismatchParam.Count != 0)
                    {
                        isSuccess = false;
                        message += "مجوز کالای  " + gi.getGood().getName() + " در موارد فوق با اظهار نامه تطبیق ندارد :";
                        foreach (string currParam in mismatchParam)
                            message += currParam + ",";
                        message += "\n";
                    }
                }
            }
            return new Result(isSuccess, message);
        }

        public void executeEzharPermits(Ezhar ezhar)
        {
            int permitId;
            int? quantity;
            foreach (GoodItem gi in ezhar.getGoods())
            {
                foreach (KeyValuePair<PermissionType, string> entry in gi.getPermisions())
                {
                    string permitIdStr = entry.Value;
                    if (permitIdStr != "")
                    {
                        permitId = Convert.ToInt32(permitIdStr);
                        Permission permission = permissionDAO.getInstance().findPermissionById(permitId);
                        quantity = permission.getQuantity();
                        if (quantity != null)
                        {
                            permissionDAO.getInstance().updatePermission(permitId, quantity.Value - gi.getQuntity());
                        }
                    }
                }
            }
        }


    }
}
