﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1.logic
{
    class Result
    {
        private bool success;
        private string message;

        public Result(bool success, string message)
        {
            this.success = success;
            this.message = message;
        }

        public bool isSuccess()
        {
            return success;
        }

        public string getMessage(){
            return message;
        }
    }
}
