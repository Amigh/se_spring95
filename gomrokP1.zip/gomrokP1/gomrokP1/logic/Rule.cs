﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1.logic
{
    class MyRule
    {
        private int id;
        private Good good;
        private int? minQuantity;
        private int? maxQuantity;
        private int? minFee;
        private int? maxFee;
   
        private int permits;

       

        public MyRule(int id, Good good, int? minQuantity, int? maxQuantity, int? minFee, int? maxFee,int permits)
        {
            this.id = id;
            this.good = good;
            this.minQuantity = minQuantity;
            this.maxQuantity = maxQuantity;
            this.minFee = minFee;
            this.maxFee = maxFee;
            this.permits = permits;
        }



        public int getPermit()
        {
            return permits;
        }


        public int getId()
        {
            return id;
        }

        public Good getGood()
        {
            return good;
        }

		public int? getMinQuantity(){
			return minQuantity;
		}

        public int? getMaxQuantity()
        {
            return maxQuantity;
        }

        public int? getMinFee()
        {
            return minFee;
        }

        public int? getMaxFee()
        {
            return maxFee;
        }

      
    }
}
