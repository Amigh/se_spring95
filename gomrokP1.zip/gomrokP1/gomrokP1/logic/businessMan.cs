﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1.logic
{
    class businessMan
    {
        public string fname;
        public string lname;
        public string ssn;
        public businessMan(string fname,string lname,string ssn)
        {
            this.fname = fname;
            this.lname = lname;
            this.ssn = ssn;
        }
    }
}
