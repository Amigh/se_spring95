﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1.logic

{
    class PermissionRole
    {
        public int permissionTypeId;
        public string role;
        public PermissionRole(int permissionTypeId,string role)
        {
            this.permissionTypeId = permissionTypeId;
            this.role = role;
        }
    }
}
