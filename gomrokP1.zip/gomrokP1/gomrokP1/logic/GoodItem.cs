﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using gomrokP1.logic;
namespace gomrokP1
{
    public class GoodItem
    {
        private Good good;

        private Description description;
        private int quntity;
        private Dictionary<PermissionType, String> permissions;

        public GoodItem(Good good, int quntity,Description des)
        {
            this.good = good;
            this.quntity = quntity;
            this.description = des;
            this.permissions = new Dictionary<PermissionType, string>();
        }
        public Good getGood()
        {
            return good;
        }

        public Description getDescription()
        {
            return description;
        }
        public int getQuntity()
        {
            return this.quntity;
        }

        public void addPermission(String permissionId,PermissionType permissionType)
        {
            permissions.Add(permissionType, permissionId);
        }

        public void clearPermissions()
        {
            permissions.Clear();
        }

        public Dictionary<PermissionType, String> getPermisions() {
            return permissions;
        }
    }

}
