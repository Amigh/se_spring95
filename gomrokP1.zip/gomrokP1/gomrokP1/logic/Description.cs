﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1.logic
{
    public class Description
    {
        public string company;
        public int weight;
        public int fee;
        public int id;
        public int goodId;
       

        public Description(string company,int weight,int fee,int id,int goodId)
        {
            this.company = company;
            this.weight = weight;
            this.fee = fee;
            this.id = id;
            this.goodId = goodId;
          
        }
    }
}
