﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1
{
    class Permission
    {
        private int id;
        private int permissionTypeId;
        private Good good;
        private string busManSSN;
        private int? quantity;
        private DateTime? expDate;
        private string compony;
        private string transportType;
        private int? minFee;
        private int? maxFee;
        private string empUserName;
        private string srcCountry;



        public Permission(int permissionTypeId,Good good, string busManSSN, int? quantity, DateTime? expDate, string compony, string transportType, int? minFee, int? maxFee, string empUserName, string srcCountry)
        {
            this.permissionTypeId = permissionTypeId;
            this.good = good;
            this.busManSSN = busManSSN;
            this.quantity = quantity;
            this.expDate = expDate;
            this.compony = compony;
            this.transportType = transportType;
            this.minFee = minFee;
            this.maxFee = maxFee;
            this.empUserName = empUserName;
            this.srcCountry = srcCountry;
        }

        public int getPermissionTypeId(){
            return permissionTypeId;
        }

        public int getId(){
            return id;
        }

        public Good getGood()
        {
            return good;
        }

        public string getBusManSSN()
        {
            return busManSSN;
        }

        public int? getQuantity()
        {
            return quantity;
        }

        public DateTime? getExpDate()
        {
            return expDate;
        }

        public string getCompony(){
            return compony;
        }

        public string getTransportType()
        {
            return transportType;
        }

        public int? getMinFee()
        {
            return minFee;
        }

        public int? getMaxFee()
        {
            return maxFee;
        }

        public string getEmpUserName(){
            return empUserName;
        }

        public void setEmpUserName(string empUserName)
        {
            this.empUserName = empUserName;
        }
        public string getSrcCountry()
        {
            return srcCountry;
        }

    }
}
