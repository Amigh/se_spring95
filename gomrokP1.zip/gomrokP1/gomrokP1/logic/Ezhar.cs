﻿using gomrokP1.logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1
{
    class Ezhar
    {
        private businessMan bm;
        private DateTime date;
        private double totalVal;
        private string sCountry;
        private string transport;
        private List<GoodItem> goods;
        public Ezhar(string fName, string lName, string ssn, DateTime date, double totalVal, string sCountry, string transport, List<GoodItem> goods)
        {
            bm = new businessMan(fName, lName, ssn);
            this.date = date;
            this.totalVal = totalVal;
            this.sCountry = sCountry;
            this.transport = transport;
            this.goods = goods;
        }
        
        public businessMan getBusinessMan()
        {
            return bm;
        }

        public DateTime getDate()
        {
            return date;
        }
        public double getTotalVal()
        {
            return totalVal;
        }
        public string getSourceCountry()
        {
            return sCountry;
        }
        public string getTransportType()
        {
            return transport;
        }
        public List<GoodItem> getGoods()
        {
            return goods;
        }
    }
}
