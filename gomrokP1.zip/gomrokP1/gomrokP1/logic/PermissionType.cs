﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gomrokP1.logic
{
    public class PermissionType
    {
        public int id;
        public string description;
        public PermissionType(int id,string description)
        {
            this.id = id;
            this.description = description;
        }
    }
}
