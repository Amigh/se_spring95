﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace gomrokP1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            MyInit();
        }

        private void login_Click(object sender, EventArgs e)
        {
            string username = this.username.Text;
            string password = this.password.Text;
            Employee user = DB.getDB().getUser(username);
            if (user == null || user.authenticate(username, password) == false)
                this.wrongNotif.Visible = true;
            else
            {
                Program.loginForm.Visible = false;
                Program.mainForm.Visible = true;
            }


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       
    }
}


