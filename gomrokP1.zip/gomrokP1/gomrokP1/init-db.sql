CREATE TABLE [dbo].[bus_man] (
    [firstName] VARCHAR (100) NOT NULL,
    [lastName]  VARCHAR (100) NOT NULL,
    [ssn]       VARCHAR (10)  NOT NULL,
    CONSTRAINT [PK_bus_man] PRIMARY KEY CLUSTERED ([ssn] ASC)
);


CREATE TABLE [dbo].[description] (
    [Id]      INT           IDENTITY (1, 1) NOT NULL,
    [fee]     INT           NOT NULL,
    [weight]  INT           NOT NULL,
    [company] VARCHAR (100) NOT NULL,
    [goodId]  INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_description_id] FOREIGN KEY ([goodId]) REFERENCES [dbo].[good] ([Id])
);

CREATE TABLE [dbo].[ezhar_goods] (
    [description_id] INT NOT NULL,
    [ezhar_id]       INT NOT NULL,
    [quantity]       INT NOT NULL,
    CONSTRAINT [PK_ezhar_goods] PRIMARY KEY CLUSTERED ([ezhar_id] ASC, [description_id] ASC),
    CONSTRAINT [FK_ezhar_goods_ToDescription] FOREIGN KEY ([description_id]) REFERENCES [dbo].[description] ([Id]),
    CONSTRAINT [FK_ezhar_goods_ToEzhar] FOREIGN KEY ([ezhar_id]) REFERENCES [dbo].[ezharname] ([Id])
);


CREATE TABLE [dbo].[ezharname] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [bus_man_ssn]    VARCHAR (10)  NOT NULL,
    [emp_username]   VARCHAR (100) NOT NULL,
    [submit_date]    DATE          NOT NULL,
    [total_val]      FLOAT (53)    NOT NULL,
    [source_country] VARCHAR (20)  NOT NULL,
    [transport_type] VARCHAR (10)  NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ezharname_buman] FOREIGN KEY ([bus_man_ssn]) REFERENCES [dbo].[bus_man] ([ssn]),
    CONSTRAINT [FK_ezharname_emp_username] FOREIGN KEY ([emp_username]) REFERENCES [dbo].[user] ([username])
);



CREATE TABLE [dbo].[good] (
    [Id]   INT          IDENTITY (1, 1) NOT NULL,
    [name] VARCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


CREATE TABLE [dbo].[permission] (
    [Id]                 INT           IDENTITY (10000000, 1) NOT NULL,
    [good_id]            INT           NOT NULL,
    [bus_man_ssn]        VARCHAR (10)  NOT NULL,
    [quantity]           INT           NULL,
    [expire_date]        DATE          NULL,
    [compony]            VARCHAR (10)  NULL,
    [transport_type]     VARCHAR (10)  NULL,
    [fee_min]            INT           NULL,
    [fee_max]            INT           NULL,
    [emp_username]       VARCHAR (100) NULL,
    [source_country]     VARCHAR (20)  NULL,
    [permission_type_id] INT           NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([permission_type_id]) REFERENCES [dbo].[permissionType] ([Id]),
    FOREIGN KEY ([good_id]) REFERENCES [dbo].[good] ([Id]),
    FOREIGN KEY ([bus_man_ssn]) REFERENCES [dbo].[bus_man] ([ssn]),
    FOREIGN KEY ([emp_username]) REFERENCES [dbo].[user] ([username])
);

CREATE TABLE [dbo].[permissionRole] (
    [permissionType] INT           NOT NULL,
    [role]           VARCHAR (100) NOT NULL,
    [id]             INT           IDENTITY (1, 1) NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_permissionRole_ToPermissionType] FOREIGN KEY ([permissionType]) REFERENCES [dbo].[permissionType] ([Id])
);

CREATE TABLE [dbo].[permissionType] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [description] VARCHAR (100) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


CREATE TABLE [dbo].[rule] (
    [Id]             INT IDENTITY (1, 1) NOT NULL,
    [good_id]        INT NULL,
    [min_quantity]   INT NULL,
    [max_quantity]   INT NULL,
    [min_fee]        INT NULL,
    [max_fee]        INT NULL,
    [permissionType] INT NULL,
    CONSTRAINT [PK_rule] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [good_id_fk] FOREIGN KEY ([good_id]) REFERENCES [dbo].[good] ([Id]),
    CONSTRAINT [permission_id_fk] FOREIGN KEY ([permissionType]) REFERENCES [dbo].[permissionType] ([Id])
);

CREATE TABLE [dbo].[user] (
    [username] VARCHAR (100) NOT NULL,
    [password] VARCHAR (100) NOT NULL,
    [role]     VARCHAR (100) NOT NULL,
    PRIMARY KEY CLUSTERED ([username] ASC)
);
