﻿namespace gomrokP1
{
    partial class AddPermissionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 

        private void hasExpDatChanged(object sender, System.EventArgs e)
        {
            if (this.hasExpDate.Checked)
            {
                this.expDate.Visible = true;
            }
            else if (this.noExpDate.Checked)
            {
                this.expDate.Visible = false;
            }
        }

        private void clearForm()
        {
            this.ssn.Text = "";
            this.goodName.Text = "";
            this.quantity.Text = "";
            this.compony.Text = "";
            this.transport.Text = "";
            this.minFee.Text = "";
            this.maxFee.Text = "";
            this.srcCountry.Text = "";
            this.expDate.Visible = false;
            this.hasExpDate.Checked = false;
            this.noExpDate.Checked = false;
            this.permitType.Text = "";
        }

        private void customInit(){
            this.resMsg.Text = "";
            this.expDate.Visible = false;
            this.hasExpDate.CheckedChanged += new System.EventHandler(hasExpDatChanged);
            this.noExpDate.CheckedChanged += new System.EventHandler(hasExpDatChanged);
        }

        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.transport = new System.Windows.Forms.DomainUpDown();
            this.expDate = new System.Windows.Forms.DateTimePicker();
            this.srcCountry = new System.Windows.Forms.TextBox();
            this.goodName = new System.Windows.Forms.TextBox();
            this.ssn = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.compony = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.minFee = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.maxFee = new System.Windows.Forms.TextBox();
            this.addPermission = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.noExpDate = new System.Windows.Forms.RadioButton();
            this.hasExpDate = new System.Windows.Forms.RadioButton();
            this.resMsg = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.permitType = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.Location = new System.Drawing.Point(356, 271);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "نحوه ی ورود";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.Location = new System.Drawing.Point(376, 416);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "کشور مبدا";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.Location = new System.Drawing.Point(393, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "نام کالا";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(361, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "تاریخ انقضا";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(366, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "کد ملی تاجر";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // transport
            // 
            this.transport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.transport.Items.Add("هوایی");
            this.transport.Items.Add("زمینی");
            this.transport.Items.Add("دریایی");
            this.transport.Location = new System.Drawing.Point(17, 271);
            this.transport.Name = "transport";
            this.transport.Size = new System.Drawing.Size(274, 26);
            this.transport.TabIndex = 10;
            // 
            // expDate
            // 
            this.expDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.expDate.Location = new System.Drawing.Point(18, 181);
            this.expDate.Name = "expDate";
            this.expDate.Size = new System.Drawing.Size(273, 26);
            this.expDate.TabIndex = 9;
            // 
            // srcCountry
            // 
            this.srcCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.srcCountry.Location = new System.Drawing.Point(18, 413);
            this.srcCountry.Name = "srcCountry";
            this.srcCountry.Size = new System.Drawing.Size(273, 26);
            this.srcCountry.TabIndex = 4;
            // 
            // goodName
            // 
            this.goodName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.goodName.Location = new System.Drawing.Point(18, 24);
            this.goodName.Name = "goodName";
            this.goodName.Size = new System.Drawing.Size(273, 26);
            this.goodName.TabIndex = 5;
            // 
            // ssn
            // 
            this.ssn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.ssn.Location = new System.Drawing.Point(18, 65);
            this.ssn.Name = "ssn";
            this.ssn.Size = new System.Drawing.Size(273, 26);
            this.ssn.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(380, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "تعداد کالا";
            // 
            // quantity
            // 
            this.quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.quantity.Location = new System.Drawing.Point(18, 106);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(273, 26);
            this.quantity.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(331, 224);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "شرکت تولید کننده";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // compony
            // 
            this.compony.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.compony.Location = new System.Drawing.Point(18, 224);
            this.compony.Name = "compony";
            this.compony.Size = new System.Drawing.Size(273, 26);
            this.compony.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.Location = new System.Drawing.Point(336, 315);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "حداقل قیمت واحد";
            // 
            // minFee
            // 
            this.minFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.minFee.Location = new System.Drawing.Point(18, 315);
            this.minFee.Name = "minFee";
            this.minFee.Size = new System.Drawing.Size(273, 26);
            this.minFee.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.Location = new System.Drawing.Point(329, 364);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "حداکثر قیمت واحد";
            // 
            // maxFee
            // 
            this.maxFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.maxFee.Location = new System.Drawing.Point(18, 364);
            this.maxFee.Name = "maxFee";
            this.maxFee.Size = new System.Drawing.Size(273, 26);
            this.maxFee.TabIndex = 22;
            // 
            // addPermission
            // 
            this.addPermission.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addPermission.Location = new System.Drawing.Point(18, 575);
            this.addPermission.Name = "addPermission";
            this.addPermission.Size = new System.Drawing.Size(428, 48);
            this.addPermission.TabIndex = 24;
            this.addPermission.Text = "صدور مجوز";
            this.addPermission.UseVisualStyleBackColor = true;
            this.addPermission.Click += new System.EventHandler(this.addPermission_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(381, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 16);
            this.label10.TabIndex = 25;
            this.label10.Text = "*";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(357, 71);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 16);
            this.label11.TabIndex = 26;
            this.label11.Text = "*";
            // 
            // noExpDate
            // 
            this.noExpDate.AutoSize = true;
            this.noExpDate.Location = new System.Drawing.Point(244, 148);
            this.noExpDate.Name = "noExpDate";
            this.noExpDate.Size = new System.Drawing.Size(47, 17);
            this.noExpDate.TabIndex = 27;
            this.noExpDate.TabStop = true;
            this.noExpDate.Text = "ندارد";
            this.noExpDate.UseVisualStyleBackColor = true;
            this.noExpDate.CheckedChanged += new System.EventHandler(this.noExpDate_CheckedChanged);
            // 
            // hasExpDate
            // 
            this.hasExpDate.AutoSize = true;
            this.hasExpDate.Location = new System.Drawing.Point(157, 148);
            this.hasExpDate.Name = "hasExpDate";
            this.hasExpDate.Size = new System.Drawing.Size(43, 17);
            this.hasExpDate.TabIndex = 28;
            this.hasExpDate.TabStop = true;
            this.hasExpDate.Text = "دارد";
            this.hasExpDate.UseVisualStyleBackColor = true;
            // 
            // resMsg
            // 
            this.resMsg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.resMsg.ForeColor = System.Drawing.Color.Red;
            this.resMsg.Location = new System.Drawing.Point(18, 544);
            this.resMsg.Name = "resMsg";
            this.resMsg.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.resMsg.Size = new System.Drawing.Size(431, 14);
            this.resMsg.TabIndex = 29;
            this.resMsg.Text = "پیام خطا";
            this.resMsg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label12.Location = new System.Drawing.Point(376, 464);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 20);
            this.label12.TabIndex = 31;
            this.label12.Text = "نوع مجوز";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // permitType
            // 
            this.permitType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.permitType.Location = new System.Drawing.Point(18, 461);
            this.permitType.Name = "permitType";
            this.permitType.Size = new System.Drawing.Size(273, 26);
            this.permitType.TabIndex = 30;
            // 
            // AddPermissionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 644);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.permitType);
            this.Controls.Add(this.resMsg);
            this.Controls.Add(this.hasExpDate);
            this.Controls.Add(this.noExpDate);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.addPermission);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.maxFee);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.minFee);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.compony);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.transport);
            this.Controls.Add(this.expDate);
            this.Controls.Add(this.srcCountry);
            this.Controls.Add(this.goodName);
            this.Controls.Add(this.ssn);
            this.Name = "AddPermissionForm";
            this.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.Text = "صدور مجوز";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DomainUpDown transport;
        private System.Windows.Forms.DateTimePicker expDate;
        private System.Windows.Forms.TextBox srcCountry;
        private System.Windows.Forms.TextBox goodName;
        private System.Windows.Forms.TextBox ssn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox quantity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox compony;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox minFee;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox maxFee;
        private System.Windows.Forms.Button addPermission;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton noExpDate;
        private System.Windows.Forms.RadioButton hasExpDate;
        private System.Windows.Forms.Label resMsg;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox permitType;
    }
}