﻿namespace gomrokP1.presentation
{
    partial class RuleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.product = new System.Windows.Forms.TextBox();
            this.minQuantity = new System.Windows.Forms.TextBox();
            this.maxQuantity = new System.Windows.Forms.TextBox();
            this.minPrice = new System.Windows.Forms.TextBox();
            this.maxPrice = new System.Windows.Forms.TextBox();
            this.permitId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.submit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.permitList = new System.Windows.Forms.ListView();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // product
            // 
            this.product.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.product.Location = new System.Drawing.Point(17, 26);
            this.product.Name = "product";
            this.product.Size = new System.Drawing.Size(176, 31);
            this.product.TabIndex = 5;
            // 
            // minQuantity
            // 
            this.minQuantity.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.minQuantity.Location = new System.Drawing.Point(17, 63);
            this.minQuantity.Name = "minQuantity";
            this.minQuantity.Size = new System.Drawing.Size(176, 31);
            this.minQuantity.TabIndex = 6;
            // 
            // maxQuantity
            // 
            this.maxQuantity.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.maxQuantity.Location = new System.Drawing.Point(17, 100);
            this.maxQuantity.Name = "maxQuantity";
            this.maxQuantity.Size = new System.Drawing.Size(176, 31);
            this.maxQuantity.TabIndex = 7;
            // 
            // minPrice
            // 
            this.minPrice.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.minPrice.Location = new System.Drawing.Point(17, 137);
            this.minPrice.Name = "minPrice";
            this.minPrice.Size = new System.Drawing.Size(176, 31);
            this.minPrice.TabIndex = 8;
            // 
            // maxPrice
            // 
            this.maxPrice.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.maxPrice.Location = new System.Drawing.Point(17, 174);
            this.maxPrice.Name = "maxPrice";
            this.maxPrice.Size = new System.Drawing.Size(176, 31);
            this.maxPrice.TabIndex = 9;
            this.maxPrice.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // permitId
            // 
            this.permitId.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.permitId.Location = new System.Drawing.Point(107, 216);
            this.permitId.Name = "permitId";
            this.permitId.Size = new System.Drawing.Size(86, 31);
            this.permitId.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(237, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 26);
            this.label1.TabIndex = 13;
            this.label1.Text = "نام کالا";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(208, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 26);
            this.label2.TabIndex = 14;
            this.label2.Text = "حداقل تعداد";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(204, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 26);
            this.label3.TabIndex = 15;
            this.label3.Text = "حداکثر تعداد";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(206, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 26);
            this.label4.TabIndex = 16;
            this.label4.Text = "حداقل قیمت";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.Location = new System.Drawing.Point(202, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 26);
            this.label5.TabIndex = 17;
            this.label5.Text = "حداکثر قیمت";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.Location = new System.Drawing.Point(225, 221);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 26);
            this.label8.TabIndex = 20;
            this.label8.Text = "نوع مجوز";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // submit
            // 
            this.submit.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.submit.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.submit.Location = new System.Drawing.Point(28, 347);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(260, 33);
            this.submit.TabIndex = 21;
            this.submit.Text = "ثبت";
            this.submit.UseVisualStyleBackColor = false;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.button1.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button1.Location = new System.Drawing.Point(17, 216);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 33);
            this.button1.TabIndex = 22;
            this.button1.Text = "اضافه کردن";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // permitList
            // 
            this.permitList.BackColor = System.Drawing.SystemColors.Menu;
            this.permitList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.permitList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.permitList.LabelWrap = false;
            this.permitList.Location = new System.Drawing.Point(28, 255);
            this.permitList.Name = "permitList";
            this.permitList.RightToLeftLayout = true;
            this.permitList.Size = new System.Drawing.Size(161, 71);
            this.permitList.TabIndex = 24;
            this.permitList.UseCompatibleStateImageBehavior = false;
            this.permitList.View = System.Windows.Forms.View.List;
            this.permitList.SelectedIndexChanged += new System.EventHandler(this.permitList_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.Location = new System.Drawing.Point(203, 267);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "لیست مجوزها";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // RuleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 391);
            this.Controls.Add(this.permitList);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.permitId);
            this.Controls.Add(this.maxPrice);
            this.Controls.Add(this.minPrice);
            this.Controls.Add(this.maxQuantity);
            this.Controls.Add(this.minQuantity);
            this.Controls.Add(this.product);
            this.Name = "RuleForm";
            this.Text = "RuleForm1";
            this.Load += new System.EventHandler(this.RuleForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox product;
        private System.Windows.Forms.TextBox minQuantity;
        private System.Windows.Forms.TextBox maxQuantity;
        private System.Windows.Forms.TextBox minPrice;
        private System.Windows.Forms.TextBox maxPrice;
        private System.Windows.Forms.TextBox permitId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.ListView permitList;
        private System.Windows.Forms.Label label9;
    }
}