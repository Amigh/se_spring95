﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using gomrokP1.logic;

namespace gomrokP1
{
    class PermissionInputPanel
    {
        private GoodItem gi;
        private PermissionType pt;
        public TextBox permitIdInput;
        public Label permissionTypeDescription;


        public PermissionInputPanel(GoodItem gi,PermissionType pt)
        {
            this.gi = gi;
            this.pt = pt;
            this.permitIdInput = new TextBox();
            this.permissionTypeDescription = new Label();
            this.permissionTypeDescription.Size = new System.Drawing.Size(210, 20);
            this.permissionTypeDescription.Text = pt.description + " برای " +  gi.getGood().getName();
        }

        public GoodItem getGoodItem(){
            return gi;
        }

        public PermissionType getPermissionType(){
            return pt;
        }

    }
}
