﻿using gomrokP1.logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace gomrokP1.presentation
{
    public partial class addPermissionType : Form
    {
        List<string> roles = new List<string>();
        public addPermissionType()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void addPermissionType_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PermissionType pt = new PermissionType(-1, this.description.Text);
            BusinessLayer bl = BusinessLayer.getInstance();
            int permissionTypeId = bl.addPermissionType(pt);

            foreach(string r in roles)
            {
                bl.addPermissionRole(new PermissionRole(permissionTypeId,r));
            }

            this.Close();
        }

     

       

        private void addrole_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.ListViewItem temp = new System.Windows.Forms.ListViewItem(this.role.Text);
            this.roleList.Items.Add(temp);
            this.roles.Add(this.role.Text);
            this.role.Text = "";
        }
    }
}
