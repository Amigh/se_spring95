﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using gomrokP1.logic;
using System.Windows.Forms;

namespace gomrokP1
{
    public partial class AddGoodForm : Form
    {
        public AddGoodForm()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Good good = new Good(this.kName.Text,-1);
            Description description = new Description(this.pName.Text, Convert.ToInt32(this.weight.Text), Convert.ToInt32(this.fee.Text),-1,-1);
            Program.ezharForm.addToGoodList(new GoodItem(good,Convert.ToInt32(this.quntity.Text),description));
            this.Close();
        }

        private void quntity_TextChanged(object sender, EventArgs e)
        {

        }

        private void kName_TextChanged(object sender, EventArgs e)
        {

        }

        private void pName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
