﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using gomrokP1.logic;

namespace gomrokP1.presentation
{
    public partial class RuleForm : Form
    {
        List<int> permits = new List<int>();
        public RuleForm()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void RuleForm_Load(object sender, EventArgs e)
        {

        }

        private void submit_Click(object sender, EventArgs e)
        {
            BusinessLayer bl = BusinessLayer.getInstance();
            foreach (int i in permits)
            {
                MyRule rule = new MyRule(-1, new Good(this.product.Text, 0), System.Convert.ToInt32(this.minQuantity.Text),
                System.Convert.ToInt32(this.maxQuantity.Text), System.Convert.ToInt32(this.minPrice.Text),
                System.Convert.ToInt32(this.maxPrice.Text)
                , i);
                
                bl.addRule(rule);
            }
            this.Close();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.ListViewItem temp = new System.Windows.Forms.ListViewItem(this.permitId.Text);
            this.permitList.Items.Add(temp);
            this.permits.Add(System.Convert.ToInt32(this.permitId.Text));
            this.permitId.Text = "";
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void permitList_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}
