﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using gomrokP1.logic;
 
namespace gomrokP1
{
    public partial class EzharForm : Form
    {
        
        private List<GoodItem> goods = new List<GoodItem>();
        private List<PermissionInputPanel> permitInputPanels = new List<PermissionInputPanel>();

        private Ezhar createEzhar()
        {
            foreach (GoodItem gi in goods)
            {
                gi.clearPermissions();
            }

            foreach (PermissionInputPanel p in permitInputPanels)
            {
                p.getGoodItem().addPermission(p.permitIdInput.Text,p.getPermissionType());
            }
            return new Ezhar(this.fName.Text, this.lName.Text, this.ssn.Text, this.dateTimePicker1.Value, Convert.ToDouble(this.totalVal.Text), this.sCountry.Text, this.transport.Text, this.goods);
        }

        private Dictionary<GoodItem, string> getPermitsId()
        {
            Dictionary<GoodItem, string> permitsId = new Dictionary<GoodItem, string>();

            return permitsId;
        }

        public EzharForm()
        {
            InitializeComponent();
            customInit();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void EzharForm_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }


        public void addToGoodList(GoodItem good)
        {
            System.Windows.Forms.ListViewItem temp = new System.Windows.Forms.ListViewItem(good.getGood().getName() + " :    " + good.getQuntity());
            this.goodsList.Items.Add(temp);
            this.goods.Add(good);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.submitEzharForm.Enabled = false;
            this.checkPermitsBtn.Enabled = false;
            this.resMsg.Text = "";
            AddGoodForm goodForm = new AddGoodForm();
            goodForm.Show();
        }

        private void submitEzharForm_Click(object sender, EventArgs e)
        {
            Ezhar ezhar = createEzhar();
            BusinessLayer bl = BusinessLayer.getInstance();
            bl.addEzhar(ezhar);
            BusinessLayer.getInstance().executeEzharPermits(createEzhar());
            this.Close();
        }

        private void checkPermitsBtn_Click(object sender, EventArgs e)
        {
            Result result = BusinessLayer.getInstance().isEzharPermitsCorrect(createEzhar());
            if (result.isSuccess())
            {
                this.resMsg.Text = "همه مجوز ها معتبر اند";
                this.resMsg.ForeColor = System.Drawing.Color.Green;
                this.submitEzharForm.Enabled = true;
            }
            else
            {
                this.resMsg.Text = result.getMessage();
                this.resMsg.ForeColor = System.Drawing.Color.Red;
            }
         }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void permitsPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void reqPermitsBtn_Click(object sender, EventArgs e)
        {
           this.clearPermitsTable();
           permitInputPanels.Clear();
           this.resMsg.Text = "";
           Ezhar ezhar = createEzhar();
           List<Tuple<GoodItem, PermissionType>> reqPermits = BusinessLayer.getInstance().getEzharReqPermits(ezhar);
           foreach (Tuple<GoodItem, PermissionType> currReqPermit in reqPermits)
           {
               PermissionInputPanel currPanel = new PermissionInputPanel(currReqPermit.Item1,currReqPermit.Item2);
               permitInputPanels.Add(currPanel);
               int rowIndex = this.permitsPanel.RowCount++;
               this.permitsPanel.Controls.Add(currPanel.permissionTypeDescription,0, rowIndex);
               this.permitsPanel.Controls.Add(currPanel.permitIdInput, 1, rowIndex);
           }
           this.permitsPanel.Visible = true;
           this.checkPermitsBtn.Enabled = true;
        }

        private void label9_Click_1(object sender, EventArgs e)
        {

        }

        private void resMsg_Click(object sender, EventArgs e)
        {

        }
    }
}
