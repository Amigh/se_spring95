﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace gomrokP1
{
    public partial class AddPermissionForm : Form
    {
        public AddPermissionForm()
        {
            InitializeComponent();
            customInit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void noExpDate_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void addPermission_Click(object sender, EventArgs e)
        {
            Boolean hasError = false;
            string goodName, busManSSN, compony, transportType, empUserName, srcCountry;
            int? quantity, minFee, maxFee;
            DateTime? expDate;

            this.resMsg.Text = "";
            if (this.ssn.Text == "")
            {
                this.resMsg.Text += "کد ملی تاجر اجباریست ";
                hasError = true;
            }
            if (this.goodName.Text == "")
            {
                this.resMsg.Text += "نام کالا اجباریست ";
                hasError = true;
            }
            if (this.permitType.Text == "")
            {
                this.resMsg.Text += "نوع مجوز اجباریست ";
                hasError = true;
            }
            else
            {
                if (!BusinessLayer.getInstance().doesPermissionTypeExist(Convert.ToInt32(this.permitType.Text)))
                {
                    this.resMsg.Text += "نوع مجوز وارد شده وجود ندارد";
                    hasError = true;
                }
                else if (!BusinessLayer.getInstance().isCurrUserAuthorisedForPermission(Convert.ToInt32(this.permitType.Text)))
                {
                    this.resMsg.Text += "شما اجازه صدور این نوع مجوز را ندارید";
                    hasError = true;
                }
            }
            
            if (hasError) {
                this.resMsg.ForeColor = System.Drawing.Color.Red;
                return;
            }

            goodName = this.goodName.Text;
            busManSSN = this.ssn.Text;
            if (this.quantity.Text == "")
                quantity = null;
            else
                quantity = System.Convert.ToInt16(this.quantity.Text);
            if (this.hasExpDate.Checked)
                expDate = this.expDate.Value;
            else
                expDate = null;
            if (this.compony.Text == "")
                compony = null;
            else
                compony = this.compony.Text;
            if (this.transport.Text == "")
                transportType = null;
            else
                transportType = this.transport.Text;
            if (this.minFee.Text == "")
                minFee = null;
            else
                minFee = System.Convert.ToInt16(this.minFee.Text);
            if (this.maxFee.Text == "")
                maxFee = null;
            else
                maxFee = System.Convert.ToInt16(this.maxFee.Text);
            if (this.srcCountry.Text == "")
                srcCountry = null;
            else
                srcCountry = this.srcCountry.Text;

            Permission permission = new Permission(Convert.ToInt32(this.permitType.Text),new Good(goodName, -1), busManSSN, quantity, expDate, compony, transportType, minFee, maxFee, null, srcCountry);
            string permissionCode = BusinessLayer.getInstance().addPermission(permission);
            this.resMsg.Text = "کد مجوز صادر شده :   " + permissionCode;
            this.resMsg.ForeColor = System.Drawing.Color.Green;
            this.clearForm();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
