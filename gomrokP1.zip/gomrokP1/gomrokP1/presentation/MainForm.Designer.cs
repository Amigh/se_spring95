﻿namespace gomrokP1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void customInit()
        {
            if (!BusinessLayer.getInstance().isCurrentUserAdmin())
            {
                this.registerButton.Visible = false;
                this.permissionTypeButton.Visible = false;
                this.addRule.Visible = false;
            }
        }


        
#region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.submitEzhar = new System.Windows.Forms.Button();
            this.registerButton = new System.Windows.Forms.Button();
            this.logOutButton = new System.Windows.Forms.Button();
            this.addPermissionButton = new System.Windows.Forms.Button();
            this.addRule = new System.Windows.Forms.Button();
            this.permissionTypeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // submitEzhar
            // 
            this.submitEzhar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.submitEzhar.Location = new System.Drawing.Point(77, 19);
            this.submitEzhar.Name = "submitEzhar";
            this.submitEzhar.Size = new System.Drawing.Size(150, 54);
            this.submitEzhar.TabIndex = 0;
            this.submitEzhar.Text = "ثبت اظهار نامه";
            this.submitEzhar.UseVisualStyleBackColor = true;
            this.submitEzhar.Click += new System.EventHandler(this.submitEzhar_Click);
            // 
            // registerButton
            // 
            this.registerButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.registerButton.Location = new System.Drawing.Point(77, 79);
            this.registerButton.Name = "registerButton";
            this.registerButton.Size = new System.Drawing.Size(150, 54);
            this.registerButton.TabIndex = 0;
            this.registerButton.Text = "ثبت نام کاربر";
            this.registerButton.UseVisualStyleBackColor = true;
            this.registerButton.Click += new System.EventHandler(this.registerButton_Click);
            // 
            // logOutButton
            // 
            this.logOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.logOutButton.Location = new System.Drawing.Point(77, 319);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(150, 54);
            this.logOutButton.TabIndex = 0;
            this.logOutButton.Text = "خروج";
            this.logOutButton.UseVisualStyleBackColor = true;
            this.logOutButton.Click += new System.EventHandler(this.logOutButton_Click);
            // 
            // addPermissionButton
            // 
            this.addPermissionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addPermissionButton.Location = new System.Drawing.Point(77, 139);
            this.addPermissionButton.Name = "addPermissionButton";
            this.addPermissionButton.Size = new System.Drawing.Size(150, 54);
            this.addPermissionButton.TabIndex = 1;
            this.addPermissionButton.Text = "صدور مجوز";
            this.addPermissionButton.UseVisualStyleBackColor = true;
            this.addPermissionButton.Click += new System.EventHandler(this.addPermissionButton_Click);
            // 
            // addRule
            // 
            this.addRule.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addRule.Location = new System.Drawing.Point(77, 199);
            this.addRule.Name = "addRule";
            this.addRule.Size = new System.Drawing.Size(150, 54);
            this.addRule.TabIndex = 2;
            this.addRule.Text = "ثبت قانون";
            this.addRule.UseVisualStyleBackColor = true;
            this.addRule.Click += new System.EventHandler(this.button1_Click);
            // 
            // permissionTypeButton
            // 
            this.permissionTypeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.permissionTypeButton.Location = new System.Drawing.Point(77, 259);
            this.permissionTypeButton.Name = "permissionTypeButton";
            this.permissionTypeButton.Size = new System.Drawing.Size(150, 54);
            this.permissionTypeButton.TabIndex = 3;
            this.permissionTypeButton.Text = "ثبت نوع مجوز";
            this.permissionTypeButton.UseVisualStyleBackColor = true;
            this.permissionTypeButton.Click += new System.EventHandler(this.permissionTypeButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 385);
            this.Controls.Add(this.permissionTypeButton);
            this.Controls.Add(this.addRule);
            this.Controls.Add(this.addPermissionButton);
            this.Controls.Add(this.logOutButton);
            this.Controls.Add(this.registerButton);
            this.Controls.Add(this.submitEzhar);
            this.Name = "MainForm";
            this.Text = "سامانه ی جامع گمرک";
            this.ResumeLayout(false);

        }
        #endregion
        private System.Windows.Forms.Button submitEzhar;
        private System.Windows.Forms.Button registerButton;
        private System.Windows.Forms.Button logOutButton;
        private System.Windows.Forms.Button addPermissionButton;
        private System.Windows.Forms.Button addRule;
        private System.Windows.Forms.Button permissionTypeButton;
    }
}